package com.tmdb.movies.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tmdb.movies.dao.UserBucketListDAO;
import com.tmdb.movies.model.Movie;
import com.tmdb.movies.model.UserBucketList;

@Service("UserBucketListService")
public class UserBucketListServiceImpl implements UserBucketListService {

	
	@Autowired
	UserBucketListDAO userBucketListDAO;
	
	@Override
	public List<UserBucketList> getUserCompleteList() {
		
		return (List<UserBucketList>) userBucketListDAO.findAll();
		
	}

	@Override
	public void addMovie(Movie movie) {
		userBucketListDAO.save(movie);

		
	}



}
