package com.tmdb.movies.service;

import java.util.List;

import com.tmdb.movies.model.Movie;
import com.tmdb.movies.model.UserBucketList;


public interface UserBucketListService {
	
	public List<UserBucketList> getUserCompleteList();
	public void addMovie(Movie movie);
}
