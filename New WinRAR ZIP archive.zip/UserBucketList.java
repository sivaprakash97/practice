package com.tmdb.movies.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr",name ="UserBucketList100")
public class UserBucketList {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int bucketListId;
	  
	  @Column
	    private String movieTitle;

	public UserBucketList(int bucketListId, String movieTitle) {
		super();
		this.bucketListId = bucketListId;
		this.movieTitle = movieTitle;
	}

	public UserBucketList() {
		super();
	}

	public int getBucketListId() {
		return bucketListId;
	}

	public void setBucketListId(int bucketListId) {
		this.bucketListId = bucketListId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bucketListId;
		result = prime * result + ((movieTitle == null) ? 0 : movieTitle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBucketList other = (UserBucketList) obj;
		if (bucketListId != other.bucketListId)
			return false;
		if (movieTitle == null) {
			if (other.movieTitle != null)
				return false;
		} else if (!movieTitle.equals(other.movieTitle))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserBucketList [BucketListId=" + bucketListId + ", movieTitle=" + movieTitle + "]";
	}
	  
	 
	  

}
