package com.tmdb.movies.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tmdb.movies.model.Movie;
import com.tmdb.movies.model.UserBucketList;

public interface UserBucketListDAO extends CrudRepository<UserBucketList, Integer> {

	public void save(Movie movie);

}
