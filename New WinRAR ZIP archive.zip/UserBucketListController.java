package com.tmdb.movies.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tmdb.movies.model.Movie;
import com.tmdb.movies.model.UserBucketList;
import com.tmdb.movies.service.UserBucketListService;

@Controller
public class UserBucketListController {
	
	@Autowired
	UserBucketListService userBucketListService;
	
	@RequestMapping(value = "/UserBucketList", method = RequestMethod.POST)
	public String completeBucketList(Model model) {
		model.addAttribute("bList", new UserBucketList());
		model.addAttribute("bucketList", this.userBucketListService.getUserCompleteList());
		return "UserBucketList";
	}
	@RequestMapping(value = "/AddToBucketList", method = RequestMethod.POST)
	public String completeBucketList(Model model, Movie movie) {
		model.addAttribute("bList", new UserBucketList());
		this.userBucketListService.addMovie(movie);
		return "Movielist";
	}
	
	
	

}






